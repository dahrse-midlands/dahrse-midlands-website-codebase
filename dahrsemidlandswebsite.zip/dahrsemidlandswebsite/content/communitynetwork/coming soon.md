+++
date = '2025-01-25T19:06:26Z'
draft = 'false'
title = 'DAHRSE-Midlands Community Showcase'
author = 'Godwin Yeboah' # Specify the author of the post
description = 'This place will be used to showcase DAHRSEs across the Midlands. Watch this space!' # Add a description for SEO purposes
tags = ['Community','Network', 'DAHRSE', 'Midlands'] # Add tags to categorize your content
categories = ['Community'] # Add categories to organize your content
slug = 'dahrse-midlands-community-showcase' # Customize the URL slug
#type = 'post' # Specify the content type
layout = 'single' # Specify the layout to use
featured_image = '/images/showcase.jpg' # Add a featured image
summary = 'A short summary of the content' # Add a summary for list pages
#aliases = ['/old-url/'] # Redirect old URLs to this page
#toc = true # Enable table of contents
#hidden = false # Hide the content from the list pages
+++

This place will be used to showcase DAHRSEs across the Midlands. Watch this space!