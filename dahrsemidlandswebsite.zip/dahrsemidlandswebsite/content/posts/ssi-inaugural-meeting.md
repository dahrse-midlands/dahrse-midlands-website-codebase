+++
date = '2025-01-25T18:02:26Z'
draft = 'false'
title = 'SSI Inaugural Meeting: Announcing New Fellows on January 30, 2025'
+++

DAHRSE-Midlands awarded Software Sustainability Institute (SSI) Fellowship. The inaugural meeting for announcing the fellowship will take place on Thursday 30 January 14:00-17:00 (GMT).
		
The fellowship will help foster collaboration and innovation among like-minded professionals. The announcement post is at the following SSI webpage [Introducing the 2025 Fellowship Cohort: Insights and Celebrations](https://www.software.ac.uk/news/introducing-2025-fellowship-cohort-insights-and-celebrations).

