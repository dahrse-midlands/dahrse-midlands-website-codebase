+++
date = '2025-01-25T18:06:26Z'
draft = 'false'
title = 'DAHRSE-Midlands at the RSE Midlands 2025'
+++

DAHRSE-Midlands will participate in the Software Sustainability Institute (SSI) session at the RSE Midlands 2025 Conference. RSE Midlands 2025 will take place on Monday 7th April 2025 at [The Exchange](https://conferences.bham.ac.uk/venues/the-exchange), hosted by the University of Birmingham's [Advanced Research Computing team](https://www.birmingham.ac.uk/research/arc/team).

For more detials, please go to [RSE Midlands Website - https://rse-midlands.github.io](https://rse-midlands.github.io).